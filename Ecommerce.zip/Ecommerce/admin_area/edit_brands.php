<?php
include('../includes/connect.php');
if(isset($_GET['edit_brands'])){
    $edit_brands=$_GET['edit_brands'];
    $sql="select * from tb_brand where 	brand_id =$edit_brands";
    $res=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($res);
    $brand_title=$row['brand_title'];
    // echo $category_title;
}

if(isset($_POST['edit_brands'])){
    $brand_title=$_POST['brand_title'];
    $sql_brand="update tb_brand set brand_title='$brand_title' where brand_id = $edit_brands";
    $res_brand=mysqli_query($conn,$sql_brand);
    if($res_brand){
        echo "<script>alert('Brand Updated Successfully')</script>";
        echo "<script>window.open('./index.php?view_brands','_self')</script>";
    }
}
?>

<div class="container mt-3">
    <h1 class="text-center">Edit Category</h1>
    <form action="" method="post" class="text-center">
        <div class="form-outline mb-4 w-50 m-auto">
            <label for="brand_title" class="form-label">Category Title</label>
            <input type="text" name="brand_title" id="brand_title" class="form-control" required="required" value="<?php echo $brand_title ?>">
        </div>
        <input type="submit" value="Update Brand" class="btn btn-primary px-3 mb-3" name="edit_brands">
    </form>
</div>