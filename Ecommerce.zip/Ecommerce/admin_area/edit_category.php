<?php
include('../includes/connect.php');
if(isset($_GET['edit_category'])){
    $edit_category=$_GET['edit_category'];
    $sql="select * from tb_cat where category_id=$edit_category";
    $res=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($res);
    $category_title=$row['category_title'];
    // echo $category_title;
}

if(isset($_POST['edit_cat'])){
    $cat_title=$_POST['category_title'];
    $sql_cat="update tb_cat set category_title='$cat_title' where category_id = $edit_category";
    $res_cat=mysqli_query($conn,$sql_cat);
    if($res_cat){
        echo "<script>alert('Category Updated Successfully')</script>";
        echo "<script>window.open('./index.php?view_categories','_self')</script>";
    }
}
?>

<div class="container mt-3">
    <h1 class="text-center">Edit Category</h1>
    <form action="" method="post" class="text-center">
        <div class="form-outline mb-4 w-50 m-auto">
            <label for="category_title" class="form-label">Category Title</label>
            <input type="text" name="category_title" id="category_title" class="form-control" required="required" value="<?php echo $category_title ?>">
        </div>
        <input type="submit" value="Update category" class="btn btn-primary px-3 mb-3" name="edit_cat">
    </form>
</div>