<?php
include('../includes/connect.php');
include('../funcation/common_funcation.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <script src="../js//bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

    <style>
        .admin_image {
            width: 100px;
            object-fit: contain;
        }
        .footer{
            position: absolute;
            bottom: 0;
        }
        .product_img{
            width: 100px;
            object-fit: contain;
        }
    </style>

</head>

<body>
    <div class="container-fluid p-0">
        <nav class="navbar nav-expand-lg navbar-light bg-info">
            <div class="container-fluid">
                <img src="../img/p1.jpg" alt="" class="logo">
                <nav class="navbar nav-expand-lg navbar-light bg-info">
                    <ul class="navbar-nav ">
                        <li class="nav-item">
                            <a href="" class="nav-link">Welcome Guest</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>

        <div class="bg-light">
            <h3 class="text-center p-2">Manage Details</h3>
        </div>

        <div class="row">
            <div class="col-md-12 bg-secondary p-1 d-flex align-items-center">
                <div class="p-3">
                    <a href="#"><img src="../img/p1.jpg" alt="" class="admin_image"></a>
                    <p class="text-light text-center">Admin Name</p>
                </div>
                <div class="button text-center">
                    <a href="insert_product.php"><button class="btn btn-primary">Insert Product</button></a>
                    <a href="index.php?view_product"><button class="btn btn-primary">View Product</button></a>
                    <a href="index.php?insert_category"><button class="btn btn-primary">Insert Categories</button></a>
                    <a href="index.php?view_categories"><button class="btn btn-primary">View Categories</button></a>
                    <a href="index.php?insert_brand"><button class="btn btn-primary">Insert Brands</button></a>
                    <a href="index.php?view_brands"><button class="btn btn-primary">View Brands</button></a>
                    <a href=""><button class="btn btn-primary">All Orders</button></a>
                    <a href=""><button class="btn btn-primary">List User</button></a>
                    <a href=""><button class="btn btn-primary">Logout</button></a>
                </div>
            </div>
        </div>

        <div class="container my-3">
            <?php
                if(isset($_GET['insert_category'])){
                    include('insert_cat.php');
                }
                if(isset($_GET['insert_brand'])){
                    include('insert_brand.php');
                }
                if(isset($_GET['view_categories'])){
                    include('view_categories.php');
                }
                if(isset($_GET['view_brands'])){
                    include('view_brands.php');
                }
                if(isset($_GET['edit_category'])){
                    include('edit_category.php');
                }
                if(isset($_GET['view_product'])){
                    include('view_product.php');
                }
                if(isset($_GET['edit_brands'])){
                    include('edit_brands.php');
                }
                if(isset($_GET['delete_category'])){
                    include('delete_category.php');
                }
                if(isset($_GET['delete_brands'])){
                    include('delete_brands.php');
                }
                if(isset($_GET['edit_products'])){
                    include('edit_products.php');
                }
                if(isset($_GET['delete_products'])){
                    include('delete_products.php');
                }
            ?>
        </div>

        <!-- <div class="bg-info p-3 text-center footer">
            <p>All rights @- Designed By Jainam Shah-2023</p>
        </div> -->

        <?php
            include('../includes/footer.php')
        ?>
    
    </div>
</body>

</html>