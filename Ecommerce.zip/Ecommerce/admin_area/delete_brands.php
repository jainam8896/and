<?php
include('../includes/connect.php');
// include('../funcation/common_funcation.php');
// include('../funcation/common_funcation.php');
if (isset($_GET['delete_brands'])) {
    $delete_brands = $_GET['delete_brands'];
    // echo $delete_category;

    $sql = "delete from tb_brand where brand_id = $delete_brands";
    $res = mysqli_query($conn, $sql);
    if ($res) {
        echo "<script>alert('Brand Deleted Successfully')</script>";
        echo "<script>window.open('./index.php?view_brands','_self')</script>";
    }
}
// deleteBrand();
?>