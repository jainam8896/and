<?php
include('../includes/connect.php');
// include('../funcation/common_funcation.php');
if(isset($_GET['delete_category'])){
    $delete_category = $_GET['delete_category'];
    // echo $delete_category;

    $sql="delete from tb_cat where category_id = $delete_category";
    $res=mysqli_query($conn,$sql);
    if ($res) {
        echo "<script>alert('Category Deleted Successfully')</script>";
        echo "<script>window.open('./index.php?view_categories','_self')</script>";
    }
}

// deleteCat();

?>