<?php
if(isset($_GET['delete_products'])){
    $delte_id=$_GET['delete_products'];
    // echo $delte_id;

    $sql="delete from tb_product where product_id=$delte_id";
    $res_product=mysqli_query($conn,$sql);
    if($res_product){
        echo "<script>alert('Product Deleted Successfully')</script>";
        echo "<script>window.open('./index.php?view_product','_self')</script>";
    }
}
?>