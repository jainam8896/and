<?php
// session_start();
// if(isset($_POST['addtocart'])){
// if(isset($_SESSION['cart'])){

// }
// else{
//     $_SESSION['cart'][0]=array(
//         id=>$_POST[''];
//     )
// }
// } 
?>