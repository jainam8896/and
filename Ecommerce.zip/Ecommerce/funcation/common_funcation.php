<?php

function getProducts()
{
    global $conn;

    if (!isset($_GET['category'])) {
        if (!isset($_GET['brand'])) {

            $sql = "select * from tb_product order by rand() LIMIT 0,9";
            $res = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($res)) {
                $product_id = $row['product_id'];
                $product_title = $row['product_title'];
                $product_descripition = $row['product_descripition'];
                $product_keywords = $row['product_keywords'];
                $product_image1 = $row['product_image1'];
                $product_price = $row['product_price'];
                $category_id = $row['category_id'];
                $brand_id = $row['brand_id'];
                echo "<div class='col-md-4 mb-2'>
        <form action='managecart.php' method='post'>
        <div class='card' style='width: 18rem;'>
            <input type='hidden' name='hidid' value='$product_id'>
            <input type='hidden' name='hidprice' value='$product_price'>
            <input type='hidden' name='hidtitle' value='$product_title'>
            <input type='hidden' name='hidimg' value='$product_image1'>
            <input type='hidden' name='hidqty' value='1'>
            <img src='./admin_area/product_images/$product_image1' class='card-img-top' alt='$product_title'>
                <div class='card-body'>
                    <h5 class='card-title'>$product_title</h5>
                    <p class='card-text'>$product_descripition</p>
                    <p class='card-text'>$product_price</p>
                    <button href='#' name='addtocart' class='btn btn-primary'>Add to cart</button>
                    <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </form>
        </div>";
            }
        }
    }
}

function get_all_product()
{
    global $conn;

    if (!isset($_GET['category'])) {
        if (!isset($_GET['brand'])) {

            $sql = "select * from tb_product order by rand()";
            $res = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($res)) {
                $product_id = $row['product_id'];
                $product_title = $row['product_title'];
                $product_descripition = $row['product_descripition'];
                $product_keywords = $row['product_keywords'];
                $product_image1 = $row['product_image1'];
                $product_price = $row['product_price'];
                $category_id = $row['category_id'];
                $brand_id = $row['brand_id'];
                echo "<div class='col-md-4 mb-2'>
        <div class='card' style='width: 18rem;'>
            <img src='./admin_area/product_images/$product_image1' class='card-img-top' alt='$product_title'>
                <div class='card-body'>
                    <h5 class='card-title'>$product_title</h5>
                    <p class='card-text'>$product_descripition</p>
                    <a href='#' class='btn btn-primary'>Add to cart</a>
                    <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>";
            }
        }
    }
}

function get_unique_categories()
{
    global $conn;

    if (isset($_GET['category'])) {
        $category_id = $_GET['category'];
        $sql = "select * from tb_product where category_id=$category_id";
        $res = mysqli_query($conn, $sql);
        $num_of_rows = mysqli_num_rows($res);
        if ($num_of_rows == 0) {
            echo "<h2 class='text-center text-denger'>No Stock For This Category</h2>";
        }
        while ($row = mysqli_fetch_assoc($res)) {
            $product_id = $row['product_id'];
            $product_title = $row['product_title'];
            $product_descripition = $row['product_descripition'];
            $product_keywords = $row['product_keywords'];
            $product_image1 = $row['product_image1'];
            $product_price = $row['product_price'];
            $category_id = $row['category_id'];
            $brand_id = $row['brand_id'];
            echo "<div class='col-md-4 mb-2'>
        <div class='card' style='width: 18rem;'>
            <img src='./admin_area/product_images/$product_image1' class='card-img-top' alt='$product_title'>
                <div class='card-body'>
                    <h5 class='card-title'>$product_title</h5>
                    <p class='card-text'>$product_descripition</p>
                    <a href='#' class='btn btn-primary'>Add to cart</a>
                    <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>";
        }
    }
}


function get_unique_brands()
{
    global $conn;

    if (isset($_GET['brand'])) {
        $brand_id = $_GET['brand'];
        $sql = "select * from tb_product where brand_id=$brand_id";
        $res = mysqli_query($conn, $sql);
        $num_of_rows = mysqli_num_rows($res);
        if ($num_of_rows == 0) {
            echo "<h2 class='text-center text-denger'>This Brand Is not available</h2>";
        }
        while ($row = mysqli_fetch_assoc($res)) {
            $product_id = $row['product_id'];
            $product_title = $row['product_title'];
            $product_descripition = $row['product_descripition'];
            $product_keywords = $row['product_keywords'];
            $product_image1 = $row['product_image1'];
            $product_price = $row['product_price'];
            $category_id = $row['category_id'];
            $brand_id = $row['brand_id'];
            echo "<div class='col-md-4 mb-2'>
        <div class='card' style='width: 18rem;'>
            <img src='./admin_area/product_images/$product_image1' class='card-img-top' alt='$product_title'>
                <div class='card-body'>
                    <h5 class='card-title'>$product_title</h5>
                    <p class='card-text'>$product_descripition</p>
                    <a href='#' class='btn btn-primary'>Add to cart</a>
                    <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>";
        }
    }
}

function getBrands()
{
    global $conn;
    $select_brands = "select * from tb_brand";
    $result = mysqli_query($conn, $select_brands);
    while ($row_data = mysqli_fetch_assoc($result)) {
        $brand_title = $row_data['brand_title'];
        $brand_id = $row_data['brand_id'];
        echo " <li class='nav-item'>
        <a href='index1.php?brand=$brand_id' class='nav-link text-light'>
            <h4>$brand_title</h4>
        </a>
        </li>";
    }
}

function getCategory()
{
    global $conn;
    $select_cat = "select * from tb_cat";
    $result = mysqli_query($conn, $select_cat);
    while ($row_data = mysqli_fetch_assoc($result)) {
        $cat_title = $row_data['category_title'];
        $cat_id = $row_data['category_id'];
        echo " <li class='nav-item'>
        <a href='index1.php?category=$cat_id' class='nav-link text-light'>
            <h4>$cat_title</h4>
        </a>
    </li>";
    }
}

function search_product()
{
    global $conn;
    if (isset($_GET['search_data_product'])) {
        $search_data = $_GET['search_data'];
        $sql = "select * from tb_product where product_title like '%$search_data%'";
        $res = mysqli_query($conn, $sql);
        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
                $product_id = $row['product_id'];
                $product_title = $row['product_title'];
                $product_descripition = $row['product_descripition'];
                $product_keywords = $row['product_keywords'];
                $product_image1 = $row['product_image1'];
                $product_price = $row['product_price'];
                $category_id = $row['category_id'];
                $brand_id = $row['brand_id'];
                echo "<div class='col-md-4 mb-2'>
                <div class='card' style='width: 18rem;'>
                    <img src='./admin_area/product_images/$product_image1' class='card-img-top' alt='$product_title'>
                        <div class='card-body'>
                            <h5 class='card-title'>$product_title</h5>
                            <p class='card-text'>$product_descripition</p>
                            <a href='#' class='btn btn-primary'>Add to cart</a>
                            <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View more</a>
                        </div>
                    </div>
                </div>";
            }
        } else {
            echo "<script>alert('No Product found');window.location.href='http://localhost/ecommerce/index1.php';</script>";
        }
    }
}

function view_details()
{
    global $conn;

    if (isset($_GET['product_id'])) {
        if (!isset($_GET['category'])) {
            if (!isset($_GET['brand'])) {
                $product_id = $_GET['product_id'];
                $sql = "select * from tb_product where product_id=$product_id";
                $res = mysqli_query($conn, $sql);
                while ($row = mysqli_fetch_assoc($res)) {
                    $product_id = $row['product_id'];
                    $product_title = $row['product_title'];
                    $product_descripition = $row['product_descripition'];
                    $product_keywords = $row['product_keywords'];
                    $product_image1 = $row['product_image1'];
                    $product_image2 = $row['product_image2'];
                    $product_image3 = $row['product_image3'];
                    $product_price = $row['product_price'];
                    $category_id = $row['category_id'];
                    $brand_id = $row['brand_id'];
                    echo "<div class='col-md-4 mb-2'>
        <div class='card' style='width: 18rem;'>
            <img src='./admin_area/product_images/$product_image1' class='card-img-top' alt='$product_title'>
                <div class='card-body'>
                    <h5 class='card-title'>$product_title</h5>
                    <p class='card-text'>$product_descripition</p>
                    <a href='#' class='btn btn-primary'>Add to cart</a>
                    <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>
        
        <div class='col-md-8'>
            <div class='row'>
                <div class='col-md-12'>
                    <h4 class='text-center text-info mb-5'>Related Product</h4>
                </div>
                <div class='col-3'>
                    <img src='./admin_area/product_images/$product_image2' class='card-img-top' alt='$product_title'>
                    </div>
                    <div class='col-3'>
                        <img src='./admin_area/product_images/$product_image3' class='card-img-top' alt='$product_title'>
                    </div>
                </div>
            </div>";
                }
            }
        }
    }
}


function deleteCat()
{
    global $conn;
    if (isset($_GET['delete_category'])) {
        $delete_category = $_GET['delete_category'];
        // echo $delete_category;

        $sql = "delete from tb_cat where category_id = $delete_category";
        $res = mysqli_query($conn, $sql);
        if ($res) {
            echo "<script>alert('Category Deleted Successfully')</script>";
            echo "<script>window.open('./index.php?view_categories','_self')</script>";
        }
    }
}

function deleteBrand(){
    global $conn;
    if (isset($_GET['delete_brands'])) {
        $delete_brands = $_GET['delete_brands'];
        // echo $delete_category;
    
        $sql = "delete from tb_brand where brand_id = $delete_brands";
        $res = mysqli_query($conn, $sql);
        if ($res) {
            echo "<script>alert('Brand Deleted Successfully')</script>";
            echo "<script>window.open('./index.php?view_brands','_self')</script>";
        }
    }
}

function selectCat(){
    global $conn;
    $select_query = "SELECT * FROM tb_cat";
    $result_query = mysqli_query($conn, $select_query) or die("query failed");

    while ($row = mysqli_fetch_assoc($result_query)) {
        $category_title = $row['category_title'];
        $category_id = $row['category_id'];
        echo "<option value='$category_id'>$category_title</option>";
    }
}

function selectBrand(){
    global $conn;
    $select_query = "select * from tb_brand";
    $result_query = mysqli_query($conn, $select_query);
    while ($row = mysqli_fetch_assoc($result_query)) {
        $brand_title = $row['brand_title'];
        $brand_id = $row['brand_id'];
        echo "<option value='$brand_id'>$brand_title</option>";
    }
}

function insertProduct(){
    global $conn;
    if(isset($_POST['insert_product'])){
        $product_title=$_POST['product_title'];
        $description=$_POST['description'];
        $product_keywords=$_POST['product_keywords'];
        $product_categories=$_POST['product_categories'];
        $product_brands=$_POST['product_brands'];
        $product_price=$_POST['product_price'];
        $product_status='true';
    
        $product_image1=$_FILES['product_image1']['name'];
        $product_image2=$_FILES['product_image2']['name'];
        $product_image3=$_FILES['product_image3']['name'];
    
        $temp_image1=$_FILES['product_image1']['tmp_name'];
        $temp_image2=$_FILES['product_image2']['tmp_name'];
        $temp_image3=$_FILES['product_image3']['tmp_name'];
    
        if($product_title=='' or $description=='' or $product_keywords=='' or $product_categories=='' or $product_brands=='' or $product_price=='' or $product_image1=='' or $product_image2=='' or $product_image3==''){
            echo "<script>alert('Please Fill The All Fields')</script>";
            exit();
        }else{
            move_uploaded_file($temp_image1,"./product_images/$product_image1");
            move_uploaded_file($temp_image1,"./product_images/$product_image2");
            move_uploaded_file($temp_image1,"./product_images/$product_image3");
    
            $sql = "insert into tb_product (product_title,product_descripition,product_keywords,
            category_id,brand_id,product_image1,product_image2,product_image3,
            product_price,date,status) values ('$product_title','$description','$product_keywords',
            '$product_categories','$product_brands','$product_image1','$product_image2',
            '$product_image3','$product_price',NOW(),'$product_status')";
            $res = mysqli_query($conn,$sql);
            if($res){
                echo "<script>alert('Product Inseted')</script>";
                echo "<script>window.open('./index.php?view_categories','_self')</script>";
                
            }
        }
    }
}
