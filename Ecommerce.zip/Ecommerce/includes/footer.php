<div class="bg-info p-3 text-center">
    <p>All rights @- Designed By Jainam Shah-2023</p>
</div>